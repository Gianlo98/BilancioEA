<html>
	<?php
		require("config/db_config.php");
		$database = new mysqli($db_host, $db_username, $dv_password, $db_name);
		mysqli_set_charset($database, 'utf8');
		
		session_start();
		if(!isset($_SESSION['accounts'])){
			header('Location: index.php');
			exit;
		}
		
		require("core/income_statment_utils.php");
	?>
	<style>
	</style>
	<head>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/bootstrap-theme.min.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<script src="js/jquery-2.2.4.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<link  rel="stylesheet"  href="css/select2.min.css"/>
		<script src="js/select2.min.js"></script>
	</head>
	
	<body>
        <?php require("core/navbar.php");?>
		<div class="container">
			<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
				<table class="table table-striped table-hover ">
					<tbody>
			<?php
			$accounts = $_SESSION['db_accounts'];
			function echoGrandRowID($row_id){
				global $database;
				$global_import = 0;
				
				//GRANDE RIGA
				$rows_super = $database->query("SELECT * FROM `income_statement_rows` WHERE row_id = " . $row_id);
				while ($super_row = $rows_super->fetch_object()){
					echo "<tr><td>";
					echo $super_row->row_char_identificator . ") " . $super_row->row_name . "<br>";
					echo "</td><td></td></tr>";
					
					//RIGA
					$rows = $database->query("SELECT * FROM `income_statement_rows` WHERE `income_statement_parents` = " . $super_row->row_id);
					while ($row = $rows->fetch_object()){
						
						//Stampo il nome della riga
						echo "<tr><td>";
						echo str_repeat('&nbsp;', 5). $row->row_char_identificator . ") " . $row->row_name . "<br>";
						echo "</td><td>";
						
						//cerco tutti i conti dentro quella riga
						$arrayRow = arraySearchIncomeStatmentRow($row->row_id, $_SESSION['db_accounts']);
						$accountRow = array_intersect_key($_SESSION['accounts'],$arrayRow);
						
						//Mi trovo l'importo della riga
						$import = 0;
						foreach($accountRow as $key => $value){
							if($_SESSION['db_accounts'][$key]->rectified == 0){
								$import += $value;
							}else $import -= $value;
						}
						if($row->row_id == 33) $import *= -1;
						$global_import += $import;
						
						//Stampo l'importo
						echo ($import == 0) ? "-" : number_format ($import,0,",",".");
						echo "</td></tr>";
						
						
						//SOTTORIGHE
						$child_rows = $database->query("SELECT * FROM `income_statement_rows` WHERE `income_statement_parents` = " . $row->row_id);
						while ($child_row = $child_rows->fetch_object()){
							
							//Stampo il nome della sottoriga
							echo "<tr><td>";
							echo str_repeat('&nbsp;', 10). $child_row->row_char_identificator . ") " . $child_row->row_name . "<br>";
							echo "</td><td>";
							
							//Cerco tutti i conti dentro quella riga
							$arrayRow = arraySearchIncomeStatmentRow($child_row->row_id, $_SESSION['db_accounts']);
							$accountRow = array_intersect_key($_SESSION['accounts'],$arrayRow);
							
							//Mi trovo l'importo della sottoriga
							$import = 0;
							foreach($accountRow as $key => $value){
								if($_SESSION['db_accounts'][$key]->rectified == 0){
									$import += $value;
								}else $import -= $value;
							}
							$global_import += $import;
							
							//Stampo l'importo
							echo ($import == 0) ? "-" : number_format ($import,0,",",".");
							echo"</td></tr>";
						}
					}
				}
				return $global_import;
			}
			/**	
				$aImport = echoGrandRowID(1);
				echo "<tr><td><b>Totale A</b></td><td><b>" . number_format($aImport,0,",",".") . "</b></td></tr>";
				$bImport = echoGrandRowID(7);
				echo "<tr><td><b>Totale B</b></td><td><b>" . number_format($bImport,0,",",".") . "</b></td></tr>";
				echo "<tr><td><b>Differenza tra valore e costi della produzione</b></td><td><b>" . number_format(($aImport - $bImport),0,",",".") . "</b></td></tr>";
				$cImport = echoGrandRowID(26);
				echo "<tr><td><b>Totale C</b></td><td><b>" . number_format($cImport,0,",",".") . "</b></td></tr>";
				echo "<tr><td><b>Risultato prima delle imposte</b></td><td><b>" . number_format(($aImport - $bImport + $cImport),0,",",".") . "</b></td></tr>";

                        
				$imposteImport = $_SESSION['accounts']['60.01'];
				echo "<tr><td><b>20) imposte sul reddito dell'esercizio, correnti, differite e anticipate</b></td><td><b>" . number_format($imposteImport,0,",",".") . "</b></td></tr>";	
				echo "<tr><td><h4><b>21) utile (perdita) dell'esercizio</b></h4></td><td><h4><b>" . number_format(($aImport - $bImport + $cImport - $imposteImport),0,",",".") . "</b></h4></td></tr>";	
			**/
				$res = $database->query("SELECT * FROM `income_statement_rows` WHERE `income_statement_parents` IS NULL");
				//$superRows[0] => A, $superRows[1] => B, $superRows => C, $superRows => D
				$superRows = $res->fetch_all(MYSQLI_ASSOC);
	
				//Stampo la A
				print_row($superRows[0],"SUPER");
				$aImport = 0;
				foreach(get_child_row($superRows[0]['row_id']) as $key => $value){
					$aImport += print_row($value);
					if($child = get_child_row($value['row_id'])){
						foreach ($child as $key1 => $value1){
							$aImport += print_row($value1,"CHILD");
						}
					}	
				}
				
				//Stampo la B
				print_row($superRows[1],"SUPER");
				$bImport = 0;
				foreach(get_child_row($superRows[1]['row_id']) as $key => $value){
					$bImport += print_row($value);
					if($child = get_child_row($value['row_id'])){
						foreach ($child as $key1 => $value1){
							$bImport += print_row($value1,"CHILD");
						}
					}	
				}
				
				print_custom_row("","Differenza A-B",$aImport-$bImport,"SUPER");
				
				//Stampo la C
				print_row($superRows[2],"SUPER");
				$cImport = 0;
				foreach(get_child_row($superRows[2]['row_id']) as $key => $value){
					$cImport += print_row($value);
					if($child = get_child_row($value['row_id'])){
						foreach ($child as $key1 => $value1){
							$cImport += print_row($value1,"CHILD");
						}
					}	
				}
				
				//Stampo la D
				print_row($superRows[3],"SUPER");
				$dImport = 0;
				foreach(get_child_row($superRows[3]['row_id']) as $key => $value){
					$dImport += print_row($value);
					if($child = get_child_row($value['row_id'])){
						foreach ($child as $key1 => $value1){
							$dImport += print_row($value1,"CHILD");
						}
					}	
				}
				
				print_custom_row("","Risultato prima delle imposte", $aImport - $bImport + $cImport + $dImport ,"SUPER");
				
				$taxImport = empty($_SESSION['accounts']['60.01']) ? 0 : $_SESSION['accounts']['60.01'];
				print_custom_row($superRows[4]['row_char_identificator'],$superRows[4]['row_name'],$taxImport);
				print_custom_row("",$superRows[5]['row_name'], $aImport - $bImport + $cImport + $dImport - $taxImport, "SUPER");
				
				
			?>
					</tbody>
				</table>
			</form>
		</div>
	</body>
</html>