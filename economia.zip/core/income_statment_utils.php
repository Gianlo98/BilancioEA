<?php 

//Ritorna un array col formato [id_conto] => obj_conto di tutti i conti dentro la riga con id $_row_id
function get_row_accounts($row_id){
	global $database;
	$array =  array();
	$accounts = array();
	
	//Ottengo tutti gli account e li salvo in $accounts[id_conto] => obj_conto
	$result = $database->query("SELECT * FROM `accounts`");
	while($row =  $result->fetch_object()){
		$accounts[$row->accounts_id] = $row;
	}
	
	//Vedo se quel conto rientra nella riga $row_id 
	foreach ($accounts as $key => $value){
		if($value->income_statement_row_id == $row_id){
			$array[$key] = $value;
		}
	}
	
	$result->close();
	return $array;
}

//Ritorna un array contenente i dati di una sola riga. riga[0] = rigaCercata['id_conto', 'nome_conto'....]
function get_data_row($row_id){
	global $database;
	$rows = $database->query("SELECT * FROM `income_statement_rows` WHERE row_id = " . $row_id);
	$array = $rows->fetch_all(MYSQLI_ASSOC);
	return (empty($array))? false : $array;
}

//Mi ritorna un array con tutte le righe "FIGLIE" di quella riga. Ritorna un array simile a questo: $righeFiglie[0] = riga['id_conto', 'nome_conto'...] ....
function get_child_row($row_id){
	global $database;
	$rows = $database->query("SELECT * FROM `income_statement_rows` WHERE income_statement_parents = " . $row_id);
	$array = $rows->fetch_all(MYSQLI_ASSOC);
	return (empty($array))? false : $array;
}

//Tipo di riga: SUPER (in grassetto senza tab all'inizio), NORMAL (tab x1 inizio), CHILD(tab x2).
function print_row($row_array, $row_type="NORMAL"){
	
	//BUGFIX: Se l'utente inserisce un conto che ha 0 come valore, devo mostrare 0 e non il - !!!!!!!!!!
	
	
	//Se alla fine è null comparirà uno spazio vuoto.
	$rowImport = null;
	
	echo "<tr><td>";
	
	//Mi servono per indentare o mettere in grassetto alcune righe
	$row_type_str_start = ($row_type == "SUPER") ? "<b>" : (($row_type == "CHILD") ? str_repeat('&nbsp;', 10) : str_repeat('&nbsp;', 5));
	$row_type_str_end = ($row_type == "SUPER") ? "</b>" : "";
	
	//Stampo il nome della riga
	echo $row_type_str_start . $row_array['row_char_identificator'] . ") " . $row_array['row_name'] . $row_type_str_end;
	
	echo "</td><td>";
	
	//Se non ha sottorighe posso calcolarmi l'importo
	if (!get_child_row($row_array['row_id'])){
		
		//mi prendo tutti gli account della riga.
		$arrayRow = get_row_accounts($row_array['row_id']);
		
		//Faccio un'intersezione con il db dei conti scelti dall'utente in modo da avere un array con i soli conti della riga  $accountsRow[id_conto] => importo_conto
		$accountsRow = array_intersect_key($_SESSION['accounts'],$arrayRow);
		
		//mi salvo in un array tutti i conti e i loro importi, arrayRow + id_riga[id_conto]. ex: arrayRow2['20.01'] = {import:"10",name:"Prodotti c/vendite",rectified:0}
		$jsArray = "<script> var arrayRow".$row_array['row_id'] . " = []; ";
		
		//Inizializzo l'importo della riga
		$rowImport = 0;
		
		//Sommo ogni conto appartente alla riga che l'utente ha inserito
		foreach($accountsRow as $key => $value){
			$accountImport = $value;
			
			//Se il conto va in rettifica della riga lo moltiplico per -1
			$rowImport += ($arrayRow[$key]->rectified == 0) ? $accountImport : $accountImport * -1;
			
			//Inserisco il conto nell'array in js inerente alla riga corrente
			$jsArray .= 'arrayRow'. $row_array['row_id'] .'['. $key . '] = {name:"' . $arrayRow[$key]->accounts_name . '",import:"'. $value .'",rectified:'. $arrayRow[$key]->rectified .'};';
		}
		
		//Stampo l'importo
		echo $rowImport == 0 ? "-" : number_format ($rowImport,0,",",".");
		
		//Stampo lo script
		echo $jsArray . "</script>";
	}
	
	echo "</td></tr>";
	
	//Ritorno il valore per fare la somma di tutte le righe
	return $rowImport;
}

//Stampa una riga customizzata con valori specifici. Tipo di riga: SUPER (in grassetto senza tab all'inizio), NORMAL (tab x1 inizio), CHILD(tab x2).
function print_custom_row($row_char_identificator, $row_name, $row_import, $row_type="NORMAL"){
	
	echo "<tr><td>";
	
	$row_type_str_start = ($row_type == "SUPER") ? "<b>" : (($row_type == "CHILD") ? str_repeat('&nbsp;', 10) : str_repeat('&nbsp;', 5));
	$row_type_str_end = ($row_type == "SUPER") ? "</b>" : "";
	
	//Stampo il nome della riga
	echo $row_type_str_start . (($row_char_identificator == "") ? "" : $row_char_identificator . ") ") . $row_name . $row_type_str_end;
	
	echo "</td><td>";
	
	$row_type_imp_start = ($row_type == "SUPER") ? "<b>" : "";
	$row_type_imp_end = ($row_type == "SUPER") ? "</b>" : "";
	
	echo $row_type_imp_start . ($row_import == 0 ? "-" : number_format ($row_import,0,",",".")).  $row_type_imp_end;
	
	echo "</td></tr>";
	return $row_import;
}




?>































