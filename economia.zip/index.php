<html>
	<?php
		require("config/db_config.php");
		$database = new mysqli($db_host, $db_username, $dv_password, $db_name);
		
		mysqli_set_charset($database, 'utf8');
		
		session_start();
		if(!isset($_SESSION['accounts'])) $_SESSION['accounts'] = array();
			
		if(!isset($_SESSION['db_accounts'])) {
			$result = $database->query("SELECT * FROM `accounts`");
			$_SESSION['db_accounts'] = array();
			while($row =  $result->fetch_object()){
				//var_dump($row);
				$_SESSION['db_accounts'][$row->accounts_id] = $row;
			}
			$result->close();
		}
		
		$accounts = $_SESSION['db_accounts'];
		
		
		

		
		class account{
			
			public $import;
			public $name;
			public $id_type;
			public $nature;
			public $eccedence;
			public $categories_id;
			public $balance_sheet_row_id;
			public $income_statement_row_id;
			
			function __construct($import,$name,$id_type, $nature, $eccedence, $categories_id, $balance_sheet_row_id, $income_statement_row_id){
				$this->import = $import;
				$this->name = $name;
				$this->id_type = $id_type;
				$this->nature = $nature;
				$this->eccedence = $eccedence;
				$this->categories_id = $categories_id;
				$this->balance_sheet_row_id = $balance_sheet_row_id;
				$this->income_statement_row_id = $income_statement_row_id;
			}
			
		}
		
		if(isset($_POST['account']) && isset($_POST['import'])){
			if (intval($_POST['import'])){
				$_SESSION['accounts'][$_POST['account']] = $_POST['import'];
				$obj = $accounts[$_POST['account']];
				$account = new account($_POST['import'],$obj->accounts_name,$obj->accounts_id_type,$obj->accounts_nature,$obj->accounts_eccedence,$obj->accounts_categories_id,$obj->balance_sheet_row_id,$obj->income_statement_row_id);
			}else{
				echo'<div class="alert alert-danger">
				  <strong>Warning!</strong> Bel tentativo :-)
				</div>';
			}
		}
	
		
		if (isset($_GET['remove_id'])){
			if (array_key_exists($_GET['remove_id'], $_SESSION['accounts'])) {
				unset($_SESSION['accounts'][$_GET['remove_id']]);
				header('Location: '.$_SERVER['PHP_SELF']);
				exit;
			}
		}
	?>
	<style>
	.select2-selection__rendered {
		line-height: 35px !important;
	}

	.select2-selection {
		height: 37px !important;
	}
	.select2-container--default .select2-selection--single{
		border: 1px solid #cccccc !important;
	}
	.fa-trash:hover{
		color:#af1212;
		
	}
	</style>
	<head>

		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/bootstrap-theme.min.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<script src="js/jquery-2.2.4.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<link  rel="stylesheet"  href="css/select2.min.css"/>
		<script src="js/select2.min.js"></script>
	</head>
	
	<body>
        <?php require("core/navbar.php");?>
		<div class="container">
			<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <legend><h1><center>Inserisci conti</center></h1></legend>
				<div class="form-group">
					<div class="col-sm-5">
						<select class="select" style="width:100%;" name="account" size=20></select>
					</div>
					<div class="col-sm-3">
						<input type="number" step="0.01" id="input_import" name="import" placeholder="importo" class="form-control" style="width:100%"></input>
					</div>
					<button class="btn btn-info" type="submit" style="width: 30%">Inserisci</button>
				</div>
				<div class="form-group">
					<div class="panel panel-primary" style="">
						<div class="panel-body">
							<table class="table table-striped table-hover ">
								<thead>
									<tr>
									<th>ID</th>
									<th>Nome Conto</th>
									<th>Importo Conto</th>
									</tr>
								</thead>
								<tbody>
									<?php 
										foreach($_SESSION['accounts'] as $key => $import){
											echo "<tr>";
											echo "<td>" . $accounts[$key]->accounts_id . '</td>';
											echo "<td><div class=\"account_name test\" data-toggle=\"modal\" data-target=\"#exampleModal\" data-whatever=\"".$accounts[$key]->accounts_name."\">" . $accounts[$key]->accounts_name . '</div></td>';
											echo "<td>" . number_format ($import,0,",",".") . '</td>';
											echo "<td style=\"width:50px\"><a href=\"".$_SERVER['PHP_SELF']."?remove_id=".$accounts[$key]->accounts_id."\" style=\"color:grey\"><i class=\"fa fa-trash\" aria-hidden=\"true\"></i></a></br>";
											echo "</tr>";
										}
										if(empty($_SESSION['accounts'])){
											echo "<tr><td>Nessun conto inserito</td></tr>";
										}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<!--<div class="col-sm-2"></div>
					<a href="hub.php"><button class="btn btn-success" type="button"  href="hub.php" style="width: 60%">Elabora</button></hub>-->
			</form>
		</div>
		
		<div class="modal fade" id="accountModal" role="dialog">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Informazioni sul conto</h4>
			  </div>
			  <div class="modal-body" style="height:200px">
                    <div>
					   <div class="col-md-2 modal_account_id"></div>
                  
					   <div class="col-md-8"></div>
                  
                        <div class="col-md-2 modal_account_nature"></div>
                    </div>
                  
                    <div>
                        <div class="col-md-1"></div>

                        <div class="col-md-10 modal_account_name"></div>

                        <div class="col-md-1"></div>
                    </div>

                    <div>
                        <div class="col-md-1"></div>

                        <div class="col-md-10 modal_account_type"></div>

                        <div class="col-md-1"></div>
                    </div>
					
			  </div>
			  <div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Chiudi</button>
			  </div>
			</div>
		  </div>
		</div>
	</body>
	<script>
	$(".test").click(function(){
		var account_id;
		var account_type;
		var account_nature;
		var account_eccedence;
		var account_categories_id;
		var balance_sheet_row_id;
		var income_statement_row_id;
		
		var account_name = $(this).text();
		var modal = $("#accountModal");
		
		json = $.ajax({
			url: "core/accounts.php?accounts=" + account_name,
			success: function(response){
				json = JSON.parse(response);
				$.each(json, function(key,value){
					account_id = value[0][0]
					account_type = value[0][2]
					account_nature = value[0][3]
					account_eccedence = value[0][4]
					account_categories = key
					account_categories_id = value[0][5]
					balance_sheet_row_id = value[0][6]
					income_statement_row_id = value[0][7]
					
					modal.modal({keyboard: false})
					modal.find('.modal_account_name').html("<center><h1>" + account_name + "</h1></center>")
					modal.find('.modal_account_id').text(account_id)
					modal.find('.modal_account_categories').html("<center><h1>" + account_categories + "</h1></center>")
					modal.find('.modal_account_nature').html("<center>" + account_nature + "</center>")
					modal.find('.modal_account_type').html("<center>" + account_type + "</center>")
					//modal.find('.modal_account_eccedence').text(account_eccedence)
					//modal.find('.modal_account_balance').text((balance_sheet_row_id == null) ? income_statement_row_id : balance_sheet_row_id)
				});
			}
		});
		modal.modal('show')
	});
	
	$('.select').on('select2:select', function (evt) {
		$("#input_import").focus();
	});
	</script>
	<script src="js/select-custom.js"></script>
</html>