<?php
	$db_host = "localhost";
	$db_username = "root";
	$dv_password = "";
	$db_name = "bilancioeconomia";
?>